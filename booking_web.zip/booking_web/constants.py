BASE_URL = "https://www.booking.com"
DRIVER = r"D:/STUDY/SeleniumDriver/chromedriver_win32"
